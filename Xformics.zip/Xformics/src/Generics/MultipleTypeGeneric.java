package Generics;
class Test2<T , U>
{
    T obj1;
    U ubj2;

    Test2(T obj1, U ubj2)
    {
        this.obj1=obj1;
        this.ubj2=ubj2;
    }
    public void print()
    {
        System.out.println(obj1);
        System.out.println(ubj2);
    }
}
public class MultipleTypeGeneric {
    public static void main(String[] args) {
      Test2<String, Integer> si=new Test2<String,Integer>("James Bond",0_0_7);
      si.print();
}}
