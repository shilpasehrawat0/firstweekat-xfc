package Generics;

class Test1<T>
{
    T obj;
    Test1 (T obj)
    {
        this.obj=obj;
    }


    public void print() {
        System.out.println(this.obj);
    }
//    public T getObj()
//    {
//        return obj;
//    }
}
public class UserdefinedGenerics {
    public static void main(String[] args) {
      Test1<Integer> in= new Test1<Integer>(007);
        //System.out.println( in.getObj());
        in.print();
    }
}
