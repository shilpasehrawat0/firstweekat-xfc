package ComparingObjects;


class Movie implements Comparable<Movie>
{
    private double rating;
    private String name;
    private int year;

    @Override
    public int compareTo(Movie o) {
        return this.year-o.year;
    }
    public Movie(double rating,String name, int year)
    {
        this.year=year;
        this.name=name;
        this.rating=rating;
    }
}
public class twoObjects{
    public static void main(String[] args) {
        Movie movie1= new Movie(3.0,"Venom",2017);
        Movie movie2= new Movie(2.0,"SpiderMan-homecoming",2019);
        Movie movie3= new Movie(5.0,"SuperMan",2020);


        System.out.println(movie1.compareTo(movie2));
    }


}
