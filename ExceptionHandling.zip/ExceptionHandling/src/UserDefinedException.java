class myException extends Exception
{
    public myException(String s)
    {
      //  super(s);
         s = "dingdong";
    }
}


public class UserDefinedException {
    public static void main(String[] args) {
        try{
            throw new myException("SHuSHShuSH");
        }catch (myException e)
        {
            System.out.println("caught: "+ e + " Exception Message " +e.getMessage());
        }
    }
}
