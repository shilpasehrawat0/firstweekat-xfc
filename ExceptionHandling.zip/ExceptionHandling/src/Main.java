public class Main {
 static int dividebyZero(int a, int b)
 {
     int s= a/b;
     return s;
 }
 static int computeDivision(int a , int b)
 {
     int res= 0;
     try
     {
         res=dividebyZero(a,b);
     } catch (Exception e) {
         e.printStackTrace();
         System.out.println(e);
     }

     return res;
 }
    public static void main(String[] args) {
	// write your code here
       int a=1;
       int b=0;

       try
       {
           int i = computeDivision(a,b);
       } catch (Exception e) {
           e.printStackTrace();
           System.out.println(e.getMessage());
       }
    }
}
