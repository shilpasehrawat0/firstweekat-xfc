public class TryCatchFinally {
    public static void main(String[] args) {
        int[]arr= new int[5];

         try {
             int i =arr[6];
             System.out.println("TryBlock");
         }catch (Exception e)
         {
             System.out.println(e.getMessage());
             System.out.println(e);
         }finally {
             System.out.println("FinallyBlock");
         }

    }
}
