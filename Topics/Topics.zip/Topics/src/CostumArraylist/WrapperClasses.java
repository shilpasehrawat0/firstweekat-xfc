package CostumArraylist;

import java.util.ArrayList;

public class WrapperClasses {
    public static void main(String[] args) {
//        char ch= 'a';
//        Character CC= ch; //ref var of WrapperClass Character
//        ArrayList<Character> arrayList= new ArrayList<>();
//        arrayList.add('s');
//        System.out.println(arrayList.get(0));


//
//        Character coco='c';
//        char c= coco;

       // int a = 10;

       // Integer iobj= new Integer(a); //wrapping int a around Integer object


    }
}
