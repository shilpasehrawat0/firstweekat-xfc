package com.Xformics;

public class Singleton { //here Access Modifier is restricting the access from the main class
   // private int num=0;
    private Singleton()   //constructor has to be private
    {

    }
    private static Singleton instance;  //not dependent on the objectof class Singleton
    // object created is stored in instance variable

    public static Singleton getInstance() {  //getInstance() is used to instantiate singleton class constructor
        if(instance==null){
           instance= new Singleton();
            System.out.println("Instance created");
        }
        return instance;
    }

    public static void main(String[] args) {
        Singleton obj= Singleton.getInstance(); //static instance method
        Singleton obj1= Singleton.getInstance();
        Singleton obj2= Singleton.getInstance();

        //all three ref var are pointing towards just one object
    }
}
