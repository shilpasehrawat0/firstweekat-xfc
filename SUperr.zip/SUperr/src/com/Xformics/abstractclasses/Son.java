package com.Xformics.abstractclasses;

public class Son extends Parent{
    public Son(int age)
    {
        super(age);
        //this.age=age;
    }
    @Override
    void career() {
        System.out.println("I am Going to be a Coder");
    }

    @Override
    void partner() {
        System.out.println("I love papper pots");
    }


}
