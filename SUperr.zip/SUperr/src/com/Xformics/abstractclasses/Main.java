package com.Xformics.abstractclasses;

public class Main {
    public static void main(String[] args) {
        Son son= new Son(20);
        son.career();
        son.normal();
        Daughter daughter = new Daughter(23);
        daughter.career();
        daughter.normal();
        Parent daughter1 = new Daughter(24);

        // Parent mom= new Parent(40) we cannot make Object of abstract classes
        // we need to override its methods as in the parent class methods dont have bodies
        // and cant be called via parents object

        Parent.hello();

    }
}
