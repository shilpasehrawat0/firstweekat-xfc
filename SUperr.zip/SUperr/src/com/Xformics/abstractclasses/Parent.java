package com.Xformics.abstractclasses;

public abstract class Parent {
    public Parent(int age)
    {
        this.age=age;
        System.out.println(this.age);
    }
    int age;
    abstract void career();
    abstract void partner();

    static void hello()
    {
        System.out.println("Hello");
    }
    void normal()
    {
        System.out.println("normal method");
    }


}
