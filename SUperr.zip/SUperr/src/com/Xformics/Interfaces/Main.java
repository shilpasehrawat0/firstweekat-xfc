package com.Xformics.Interfaces;

public class Main {
    public static void main(String[] args) {
        Engine car = new Car();

//        car.accelerate();
//        car.start();
//        car.stop();
//
//        Media carMedia = new Car();
//        carMedia.stop();

        NiceCar Car = new NiceCar();
        Car.start();
        Car.startMusic();
        Car.upgradengine();
        Car.stop();
        Car.stopMusic();
    }
}
