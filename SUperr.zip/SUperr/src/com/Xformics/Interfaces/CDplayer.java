package com.Xformics.Interfaces;

public class CDplayer implements Media{
    @Override
    public void stop() {
        System.out.println("Music stop");
    }

    @Override
    public void start() {
        System.out.println("Music Start");
    }
}
