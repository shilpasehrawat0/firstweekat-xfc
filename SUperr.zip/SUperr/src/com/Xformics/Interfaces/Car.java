package com.Xformics.Interfaces;

public class Car implements Brake,Engine,Media{
    @Override
    public void brake() {
        System.out.println("I brake like a normal Car");
    }

    @Override
    public void start() {
        System.out.println(" I start eng like a normal car");
    }

    @Override
    public void stop() {
        System.out.println("I stop eng like a normal car");
    }

    @Override
    public void accelerate() {
        System.out.println("I acc like a normal car");
    }
}
