package com.Xformics.Interfaces;

public class ElectricEn implements Engine{
    @Override
    public void start() {
        System.out.println("Elecric Start");
    }

    @Override
    public void stop() {
        System.out.println("Elecric Stop");
    }

    @Override
    public void accelerate() {
        System.out.println("Electric acc");
    }
}
