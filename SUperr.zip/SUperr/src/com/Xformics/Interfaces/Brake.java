package com.Xformics.Interfaces;

public interface Brake {
    void brake();
    void start();
}
