package com.Xformics.Interfaces;

public interface Media {
    void stop();
    void start();
}

