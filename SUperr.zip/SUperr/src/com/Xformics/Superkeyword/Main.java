package com.Xformics.Superkeyword;

class person
{
    person()
    {
        System.out.println("Person constructor");
    }
}
class Student extends person
{
    Student()
    {
       // super();
        System.out.println("Student constructor");
    }
}
public class Main {

    public static void main(String[] args) {
Student a = new Student();
    }
}
