package com.Xformics;
class test{

    static String name ;

    public test(String name)
    {
        this.name =name;
    }
}
public class InnerClasses {   //outside classes cannot be static
//    static class test{    // if this is non-static then it is dependent on the Outer class hence it requires object to run
//                          // so make it static
//        String name ;
//
//        public test(String name)
//        {
//            this.name =name;
//        }
//    }


    public static void main(String[] args) {
        test a = new test("Shilpa");
        test b = new test("Sehrawat");

        System.out.println(a.name);
        System.out.println(b.name);

    }
}
